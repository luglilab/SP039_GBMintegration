```python
import numpy as np
import pandas as pd
import scanpy as sc
```


```python
adata = sc.read("/home/lugli/spuccio/Projects/SP039/GBmap/Concatenato602949K_umap_ac.h5ad")
```


```python
adata.X = adata.layers['log']
```


```python
#sc.pp.scale(adata,max_value=6)
```


```python
sc.set_figure_params(dpi=150)
```


```python
sc.pl.umap(adata, color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_5_1.png)
    



```python
adata = adata.raw.to_adata()
```


```python
sc.pl.violin(adata, ['PTPRC','CD3E','CD8A','CD4'], groupby='leiden',stripplot=False,inner='box',
             use_raw=False,jitter=False,rotation=90)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(



    
![png](output_7_1.png)
    



```python
sc.pl.umap(adata, color=['CD8A'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True,palette='tab20')
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap', 'norm' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap', 'norm' will be ignored
      ax.scatter(



    
![png](output_8_1.png)
    



```python
sc.pl.umap(adata, color=['CD4'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True,palette='tab20')
```


    
![png](output_9_0.png)
    



```python
import scprep
```


```python
scprep.plot.scatter(x=adata[:, ['CD8A']].to_df(),y=adata[:, ['CD4']].to_df(),
                    legend=False)
```




    <Axes: >




    
![png](output_11_1.png)
    



```python
scprep.plot.scatter(x=adata[:, ['CD3E']].to_df(),y=adata[:, ['CD8A']].to_df(),
                    legend=False)
```




    <Axes: >




    
![png](output_12_1.png)
    



```python

```


```python
adata[adata[: , 'CD3E'].X.A > 0, :].shape
```




    (59758, 20088)




```python
adata[(adata[: , 'CD3E'].X.A > 0) & (adata[: , 'PTPRC'].X.A > 0), :].shape
```




    (38603, 20088)




```python
sc.pl.umap(adata[(adata[: , 'CD3E'].X.A > 0), :], color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True,palette='tab20')
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_utils.py:464: ImplicitModificationWarning: Trying to modify attribute `._uns` of view, initializing view as actual.
      adata.uns[value_to_plot + "_colors"] = colors_list
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_16_1.png)
    



```python
sc.pl.umap(adata[(adata[: , 'CD3E'].X.A > 0) & (adata[: , 'PTPRC'].X.A > 0), :], color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True,palette='tab20')
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_utils.py:464: ImplicitModificationWarning: Trying to modify attribute `._uns` of view, initializing view as actual.
      adata.uns[value_to_plot + "_colors"] = colors_list
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_17_1.png)
    



```python
CD3E = adata[adata.obs['leiden'].isin(['3']),:]
```


```python

```


```python
#list_index_CD3E = adata[adata[: , 'CD3E'].X.A > 0, :].obs.index
```


```python
#CD3E = adata[adata.obs.index.isin(list_index_CD3E),:]
```


```python
scprep.plot.scatter(x=CD3E[:, ['CD8A']].to_df(),y=CD3E[:, ['CD4']].to_df(),
                    legend=False)
```




    <Axes: >




    
![png](output_22_1.png)
    



```python
list_index = CD3E[(CD3E[: , 'CD8A'].X.A > 0) & (CD3E[: , 'CD4'].X.A > 0), :].obs.index
```


```python
CD3E = CD3E[~CD3E.obs.index.isin(list_index),:]
```


```python
scprep.plot.scatter(x=CD3E[:, ['CD3E']].to_df(),y=CD3E[:, ['CD4']].to_df(),
                    legend=False)
```




    <Axes: >




    
![png](output_25_1.png)
    



```python
scprep.plot.scatter(x=CD3E[:, ['CD3E']].to_df(),y=CD3E[:, ['CD8A']].to_df(),
                    legend=False)
```




    <Axes: >




    
![png](output_26_1.png)
    



```python
sc.pl.umap(CD3E, color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_27_1.png)
    



```python
sc.pl.umap(CD3E, color=['annotation_level_3'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)

```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_28_1.png)
    



```python
sc.pl.violin(CD3E, ['CD3E','CD8A','CD4'], groupby='leiden',stripplot=False,inner='box',
             use_raw=False,jitter=False,rotation=90)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.violinplot(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_anndata.py:906: FutureWarning: 
    
    The `scale` parameter has been renamed and will be removed in v0.15.0. Pass `density_norm='width'` for the same effect.
      ax = sns.violinplot(



    
![png](output_29_1.png)
    



```python
CD3E.obs["leiden"].value_counts(normalize=True).mul(100)
```




    leiden
    3    100.0
    Name: proportion, dtype: float64




```python
#Tcell = CD3E[CD3E.obs["leiden"].isin(['1','2','11','7','6']),:]
```


```python
#Tcell = Tcell[Tcell.obs["annotation_level_3"].isin(['CD4/CD8','NotAvailable']),:]
```


```python
sc.pl.umap(CD3E, color=['annotation_level_3'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)

```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_33_1.png)
    



```python
sc.pl.umap(CD3E, color=['assay'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)

```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_34_1.png)
    



```python
del CD3E.uns['log1p']
```


```python
CD3E.uns['log1p'] = None
```

    /tmp/ipykernel_42234/3491511895.py:1: ImplicitModificationWarning: Trying to modify attribute `._uns` of view, initializing view as actual.
      CD3E.uns['log1p'] = None



```python
del CD3E.uns['log1p']
```


```python
print(CD3E.n_obs, CD3E.n_vars)
ribo_genes = CD3E.var_names.str.startswith(("RPL","RPS"))
malat1 = CD3E.var_names.str.startswith('MALAT1')
remove = np.add(ribo_genes, malat1)
keep = np.invert(remove)
CD3E = CD3E[:,keep]
print(CD3E.n_obs, CD3E.n_vars)
```

    64660 20088
    64660 19993



```python
sc.pp.highly_variable_genes(CD3E, min_mean=0.0125, max_mean=3, min_disp=0.25)
```

    /home/lugli/spuccio/scanpy/scanpy/preprocessing/_highly_variable_genes.py:577: ImplicitModificationWarning: Trying to modify attribute `._uns` of view, initializing view as actual.
      adata.uns["hvg"] = {"flavor": flavor}



```python
sc.pl.highly_variable_genes(CD3E)
```


    
![png](output_40_0.png)
    



```python
CD3E.raw = CD3E
```


```python
CD3E = CD3E[:,CD3E.var.highly_variable]
sc.pp.scale(CD3E, max_value=10)
```

    /home/lugli/spuccio/scanpy/scanpy/preprocessing/_simple.py:924: UserWarning: Received a view of an AnnData. Making a copy.
      view_to_actual(adata)



```python
sc.tl.pca(CD3E, svd_solver='arpack',random_state=0)

```


```python
sc.pl.pca_variance_ratio(CD3E, log=True, n_pcs=50)
```


    
![png](output_44_0.png)
    



```python
#sc.pp.neighbors(Tcell, n_neighbors=10, n_pcs=30)
```


```python
#sc.tl.umap(Tcell)
```


```python
import scanpy.external as sce
sce.pp.harmony_integrate(CD3E, ['author', 'donor_id','stage','assay'])
```

    2024-01-08 21:24:44,363 - harmonypy - INFO - Computing initial centroids with sklearn.KMeans...
    2024-01-08 21:24:48,501 - harmonypy - INFO - sklearn.KMeans initialization complete.
    2024-01-08 21:24:48,813 - harmonypy - INFO - Iteration 1 of 10
    2024-01-08 21:25:17,533 - harmonypy - INFO - Iteration 2 of 10
    2024-01-08 21:25:46,152 - harmonypy - INFO - Iteration 3 of 10
    2024-01-08 21:26:14,876 - harmonypy - INFO - Iteration 4 of 10
    2024-01-08 21:26:43,489 - harmonypy - INFO - Iteration 5 of 10
    2024-01-08 21:27:12,161 - harmonypy - INFO - Iteration 6 of 10
    2024-01-08 21:27:40,904 - harmonypy - INFO - Iteration 7 of 10
    2024-01-08 21:28:09,620 - harmonypy - INFO - Iteration 8 of 10
    2024-01-08 21:28:38,178 - harmonypy - INFO - Iteration 9 of 10
    2024-01-08 21:29:06,877 - harmonypy - INFO - Iteration 10 of 10
    2024-01-08 21:29:35,625 - harmonypy - INFO - Stopped before convergence



```python
CD3E.obsm['X_pca'] = CD3E.obsm['X_pca_harmony']
```


```python
sc.pp.neighbors(CD3E, n_neighbors=10, n_pcs=30)
```

    /home/lugli/spuccio/anaconda3/envs/scanpy195/lib/python3.11/site-packages/tqdm/auto.py:21: TqdmWarning: IProgress not found. Please update jupyter and ipywidgets. See https://ipywidgets.readthedocs.io/en/stable/user_install.html
      from .autonotebook import tqdm as notebook_tqdm



```python
sc.tl.umap(CD3E)
```


```python
sc.tl.leiden(CD3E, resolution=0.5)
```


```python
sc.pl.umap(CD3E[~CD3E.obs['leiden'].isin(['15','16','17'])], color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_52_1.png)
    



```python
sc.pl.umap(CD3E[~CD3E.obs['leiden'].isin(['15','16','17'])], color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, add_outline=True,legend_loc="on data")
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_53_1.png)
    



```python

```


```python
#CD3E = CD3E[~CD3E.obs['leiden'].isin(['15','16','17'])]
```


```python
adata = CD3E[~CD3E.obs['leiden'].isin(['15','16','17'])]
```


```python
sc.pl.umap(adata, color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_57_1.png)
    



```python
adata.obs['leiden'].value_counts(normalize=True).mul(100)
```




    leiden
    0     25.856548
    1     20.698607
    2     10.006529
    3      9.076918
    4      8.549932
    5      6.567902
    6      3.424636
    7      2.614725
    8      2.605397
    9      2.529225
    10     2.117274
    11     1.960266
    12     1.531215
    13     1.234299
    14     1.226527
    Name: proportion, dtype: float64




```python
adata.obs['donor_id'].unique()
```




    ['SM006', 'SM012', 'SM017', 'SM018', 'G1003', ..., 'G946_T', 'G910_T', 'G967_T', 'G983_T', 'G1003_T']
    Length: 106
    Categories (106, object): ['Breast_2', 'Colorectal', 'G523', 'G566', ..., 'ndGBM-08', 'ndGBM-09', 'ndGBM-10', 'ndGBM-11']




```python
sc.pl.umap(adata, color=['leiden'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, title="Umap After Correction",add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_60_1.png)
    



```python
sc.pl.umap(adata, color=['CD8A','CD4'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4,add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap', 'norm' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap', 'norm' will be ignored
      ax.scatter(



    
![png](output_61_1.png)
    



```python
sc.pl.umap(adata, color=['author','stage'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4,add_outline=True)
```

    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:378: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:388: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      ax.scatter(
    /home/lugli/spuccio/scanpy/scanpy/plotting/_tools/scatterplots.py:401: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



    
![png](output_62_1.png)
    



```python
adata.write("/home/lugli/spuccio/Projects/SP039/GBmap/Tcell_ac.h5ad")
```


```python
#adata = sc.read("/home/lugli/spuccio/Projects/SP039/GBmap/Tcell_ac.h5ad")
```


```python
adata = adata.raw.to_adata()
```


```python
adata
```




    AnnData object with n_obs × n_vars = 64328 × 19993
        obs: 'author', 'donor_id', 'annotation_level_1', 'annotation_level_2', 'annotation_level_3', 'stage', 'location', 'celltype_original', 'EGFR', 'MET', 'p53', 'TERT', 'ATRX', 'PTEN', 'MGMT', 'chr1p19q', 'PDGFR', 'cell_type', 'assay', 'disease', 'sex', 'tissue', 'development_stage', 'batch', 'n_genes_by_counts', 'total_counts', 'leiden'
        var: 'ensembl_gene_id-0', 'chromosome_name-0', 'description-0', 'gene_biotype-0', 'n_cells_by_counts', 'mean_counts', 'pct_dropout_by_counts', 'total_counts', 'highly_variable', 'means', 'dispersions', 'dispersions_norm'
        uns: 'annotation_level_1_colors', 'annotation_level_2_colors', 'annotation_level_3_colors', 'assay_colors', 'author_colors', 'hvg', 'leiden', 'leiden_colors', 'neighbors', 'pca', 'stage_colors', 'umap'
        obsm: 'X_pca', 'X_pca_harmony', 'X_umap'
        obsp: 'connectivities', 'distances'




```python
list_index_CD3E = adata[adata[: , 'CD3E'].X.A > 0, :].obs.index
```


```python
adata = adata[adata.obs.index.isin(list_index_CD3E),:]
```


```python
adata
```




    View of AnnData object with n_obs × n_vars = 47670 × 19993
        obs: 'author', 'donor_id', 'annotation_level_1', 'annotation_level_2', 'annotation_level_3', 'stage', 'location', 'celltype_original', 'EGFR', 'MET', 'p53', 'TERT', 'ATRX', 'PTEN', 'MGMT', 'chr1p19q', 'PDGFR', 'cell_type', 'assay', 'disease', 'sex', 'tissue', 'development_stage', 'batch', 'n_genes_by_counts', 'total_counts', 'leiden'
        var: 'ensembl_gene_id-0', 'chromosome_name-0', 'description-0', 'gene_biotype-0', 'n_cells_by_counts', 'mean_counts', 'pct_dropout_by_counts', 'total_counts', 'highly_variable', 'means', 'dispersions', 'dispersions_norm'
        uns: 'annotation_level_1_colors', 'annotation_level_2_colors', 'annotation_level_3_colors', 'assay_colors', 'author_colors', 'hvg', 'leiden', 'leiden_colors', 'neighbors', 'pca', 'stage_colors', 'umap'
        obsm: 'X_pca', 'X_pca_harmony', 'X_umap'
        obsp: 'connectivities', 'distances'




```python
sc.pl.umap(adata, color=['PTPRC','CD8A','CD4','CD3E'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, add_outline=True)
```


    
![png](output_70_0.png)
    



```python
sc.pl.umap(adata, color=['FOXP3','GZMK','HAVCR2','PDCD1'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4, add_outline=True)
```


    
![png](output_71_0.png)
    



```python
sc.pl.umap(adata, color=['CD3E','CD8A','CD4','MKI67'], legend_fontsize=6, frameon=True, ncols = 2,
                        wspace=.5, hspace=0.4,add_outline=True)
```


    
![png](output_72_0.png)
    


#Cohort


```python
#!pip install statannot
```


```python
adata.write("/home/lugli/spuccio/Projects/SP039/GBmap/Tcell_ac.h5ad")
```


```python
from statannot import add_stat_annotation
from matplotlib import pyplot as plt
```


```python
#adata.obs.groupby("leiden")["stage","donor_id"].value_counts(normalize=True).mul(100)
```


```python

```

    /tmp/ipykernel_29002/1733232195.py:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      adata.obs.groupby("donor_id")["stage","leiden"].value_counts(normalize=True).mul(100)





    donor_id  stage               leiden
    Breast_2  Metastasis          3         44.881890
                                  2         17.322835
                                  10        15.748031
                                  7          6.299213
                                  4          5.511811
                                              ...    
    rGBM-05   Metastasis          3          0.000000
                                  2          0.000000
                                  1          0.000000
                                  0          0.000000
              Recurrent neo-aPD1  10         0.000000
    Length: 7040, dtype: float64




```python

```

    /tmp/ipykernel_29002/2590894756.py:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      df = adata.obs.groupby("donor_id")["stage","leiden"].value_counts(normalize=True).mul(100)



```python
box_pairs=[
    ((0, "Metastasis"), (0, "Normal")),
    ((0, "Metastasis"), (0, "Primary")),
    ((0, "Metastasis"), (0, "Recurrent")),
    ((0, "Metastasis"), (0, "Recurrent neo-aPD1")),
    ((0, "Normal"), (0, "Primary")),
    ((0, "Normal"), (0, "Recurrent")),
    ((0, "Normal"), (0, "Recurrent neo-aPD1")),
    ((0, "Primary"), (0, "Recurrent")),
    ((0, "Primary"), (0, "Recurrent neo-aPD1")),
    ((0, "Recurrent"), (0, "Recurrent neo-aPD1")),
    ((1, "Metastasis"), (1, "Normal")),
    ((1, "Metastasis"), (1, "Primary")),
    ((1, "Metastasis"), (1, "Recurrent")),
    ((1, "Metastasis"), (1, "Recurrent neo-aPD1")),
    ((1, "Normal"), (1, "Primary")),
    ((1, "Normal"), (1, "Recurrent")),
    ((1, "Normal"), (1, "Recurrent neo-aPD1")),
    ((1, "Primary"), (1, "Recurrent")),
    ((1, "Primary"), (1, "Recurrent neo-aPD1")),
    ((1, "Recurrent"), (1, "Recurrent neo-aPD1")),
        ((2, "Metastasis"), (2, "Normal")),
    ((2, "Metastasis"), (2, "Primary")),
    ((2, "Metastasis"), (2, "Recurrent")),
    ((2, "Metastasis"), (2, "Recurrent neo-aPD1")),
    ((2, "Normal"), (2, "Primary")),
    ((2, "Normal"), (2, "Recurrent")),
    ((2, "Normal"), (2, "Recurrent neo-aPD1")),
    ((2, "Primary"), (2, "Recurrent")),
    ((2, "Primary"), (2, "Recurrent neo-aPD1")),
    ((2, "Recurrent"), (2, "Recurrent neo-aPD1")),
        ((3, "Metastasis"), (3, "Normal")),
    ((3, "Metastasis"), (3, "Primary")),
    ((3, "Metastasis"), (3, "Recurrent")),
    ((3, "Metastasis"), (3, "Recurrent neo-aPD1")),
    ((3, "Normal"), (3, "Primary")),
    ((3, "Normal"), (3, "Recurrent")),
    ((3, "Normal"), (3, "Recurrent neo-aPD1")),
    ((3, "Primary"), (3, "Recurrent")),
    ((3, "Primary"), (3, "Recurrent neo-aPD1")),
    ((3, "Recurrent"), (3, "Recurrent neo-aPD1")),
        ((4, "Metastasis"), (4, "Normal")),
    ((4, "Metastasis"), (4, "Primary")),
    ((4, "Metastasis"), (4, "Recurrent")),
    ((4, "Metastasis"), (4, "Recurrent neo-aPD1")),
    ((4, "Normal"), (4, "Primary")),
    ((4, "Normal"), (4, "Recurrent")),
    ((4, "Normal"), (4, "Recurrent neo-aPD1")),
    ((4, "Primary"), (4, "Recurrent")),
    ((4, "Primary"), (4, "Recurrent neo-aPD1")),
    ((4, "Recurrent"), (4, "Recurrent neo-aPD1")),
        ((5, "Metastasis"), (5, "Normal")),
    ((5, "Metastasis"), (5, "Primary")),
    ((5, "Metastasis"), (5, "Recurrent")),
    ((5, "Metastasis"), (5, "Recurrent neo-aPD1")),
    ((5, "Normal"), (5, "Primary")),
    ((5, "Normal"), (5, "Recurrent")),
    ((5, "Normal"), (5, "Recurrent neo-aPD1")),
    ((5, "Primary"), (5, "Recurrent")),
    ((5, "Primary"), (5, "Recurrent neo-aPD1")),
    ((5, "Recurrent"), (5, "Recurrent neo-aPD1")),
        ((6, "Metastasis"), (6, "Normal")),
    ((6, "Metastasis"), (6, "Primary")),
    ((6, "Metastasis"), (6, "Recurrent")),
    ((6, "Metastasis"), (6, "Recurrent neo-aPD1")),
    ((6, "Normal"), (6, "Primary")),
    ((6, "Normal"), (6, "Recurrent")),
    ((6, "Normal"), (6, "Recurrent neo-aPD1")),
    ((6, "Primary"), (6, "Recurrent")),
    ((6, "Primary"), (6, "Recurrent neo-aPD1")),
    ((6, "Recurrent"), (6, "Recurrent neo-aPD1")),
        ((7, "Metastasis"), (7, "Normal")),
    ((7, "Metastasis"), (7, "Primary")),
    ((7, "Metastasis"), (7, "Recurrent")),
    ((7, "Metastasis"), (7, "Recurrent neo-aPD1")),
    ((7, "Normal"), (7, "Primary")),
    ((7, "Normal"), (7, "Recurrent")),
    ((7, "Normal"), (7, "Recurrent neo-aPD1")),
    ((7, "Primary"), (7, "Recurrent")),
    ((7, "Primary"), (7, "Recurrent neo-aPD1")),
    ((7, "Recurrent"), (7, "Recurrent neo-aPD1")),
        ((8, "Metastasis"), (8, "Normal")),
    ((8, "Metastasis"), (8, "Primary")),
    ((8, "Metastasis"), (8, "Recurrent")),
    ((8, "Metastasis"), (8, "Recurrent neo-aPD1")),
    ((8, "Normal"), (8, "Primary")),
    ((8, "Normal"), (8, "Recurrent")),
    ((8, "Normal"), (8, "Recurrent neo-aPD1")),
    ((8, "Primary"), (8, "Recurrent")),
    ((8, "Primary"), (8, "Recurrent neo-aPD1")),
    ((8, "Recurrent"), (8, "Recurrent neo-aPD1")),
        ((9, "Metastasis"), (9, "Normal")),
    ((9, "Metastasis"), (9, "Primary")),
    ((9, "Metastasis"), (9, "Recurrent")),
    ((9, "Metastasis"), (9, "Recurrent neo-aPD1")),
    ((9, "Normal"), (9, "Primary")),
    ((9, "Normal"), (9, "Recurrent")),
    ((9, "Normal"), (9, "Recurrent neo-aPD1")),
    ((9, "Primary"), (9, "Recurrent")),
    ((9, "Primary"), (9, "Recurrent neo-aPD1")),
    ((9, "Recurrent"), (9, "Recurrent neo-aPD1")),
        ((10, "Metastasis"), (10, "Normal")),
    ((10, "Metastasis"), (10, "Primary")),
    ((10, "Metastasis"), (10, "Recurrent")),
    ((10, "Metastasis"), (10, "Recurrent neo-aPD1")),
    ((10, "Normal"), (10, "Primary")),
    ((10, "Normal"), (10, "Recurrent")),
    ((10, "Normal"), (10, "Recurrent neo-aPD1")),
    ((10, "Primary"), (10, "Recurrent")),
    ((10, "Primary"), (10, "Recurrent neo-aPD1")),
    ((10, "Recurrent"), (10, "Recurrent neo-aPD1")),
    ]
```


```python
import seaborn as sns
from statannotations.Annotator import Annotator
sns.set(rc={'font.family':'Arial', 'font.serif':'Arial'})
sns.set(style="whitegrid")

f, ax = plt.subplots(figsize=(20, 8))
ax = sns.boxplot(data=df2, x="leiden", y="0",hue="stage",hue_order=['Metastasis', 'Normal', 'Primary', 'Recurrent', 'Recurrent neo-aPD1'],
                 whis=[0, 100], width=.4,dodge=True)
ax = sns.stripplot(x="leiden", y="0", data=df2,hue="stage",dodge=True,hue_order=['Metastasis', 'Normal', 'Primary', 'Recurrent', 'Recurrent neo-aPD1'],
              size=2, color=".3", linewidth=1)



annot = Annotator(ax, box_pairs, data=df2, x="leiden", y="0",
               order=[0,1,2,3,4,5,6,7,8,9,10],
               hue="stage",
               hue_order=['Metastasis', 'Normal', 'Primary', 'Recurrent', 'Recurrent neo-aPD1'])
annot.configure(test='t-test_ind', verbose=2,hide_non_significant=True,
               pvalue_thresholds=[[1e-4, "****"], [1e-3, "***"], [1e-2, "**"], [0.05, "*"]])
annot.apply_test()
annot.annotate()


ax.xaxis.grid(False)
ax.set(ylabel="Relative Frequency")
ax.set(xlabel="Cluster")
sns.despine(trim=True, left=False)
plt.tight_layout()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Input In [3], in <cell line: 6>()
          3 sns.set(rc={'font.family':'Arial', 'font.serif':'Arial'})
          4 sns.set(style="whitegrid")
    ----> 6 f, ax = plt.subplots(figsize=(20, 8))
          7 ax = sns.boxplot(data=df2, x="leiden", y="0",hue="stage",hue_order=['Metastasis', 'Normal', 'Primary', 'Recurrent', 'Recurrent neo-aPD1'],
          8                  whis=[0, 100], width=.4,dodge=True)
          9 ax = sns.stripplot(x="leiden", y="0", data=df2,hue="stage",dodge=True,hue_order=['Metastasis', 'Normal', 'Primary', 'Recurrent', 'Recurrent neo-aPD1'],
         10               size=2, color=".3", linewidth=1)


    NameError: name 'plt' is not defined



```python
sc.pl.dotplot(Tcell, {" ":["PTPRC","CD3E","CD8A","CD4","FOXP3","CCR7","CD28","FAS","GZMK","TOX","PDCD1",
                          "IL7R","CD27","ZEB2","NKG7","KLRB1",]}, 'leiden', dendrogram=True)
```


```python
adata[adata.obs['stage'].isin([ 'Recurrent', 'Recurrent neo-aPD1']),:]
```




    View of AnnData object with n_obs × n_vars = 55794 × 2677
        obs: 'author', 'donor_id', 'annotation_level_1', 'annotation_level_2', 'annotation_level_3', 'stage', 'location', 'celltype_original', 'EGFR', 'MET', 'p53', 'TERT', 'ATRX', 'PTEN', 'MGMT', 'chr1p19q', 'PDGFR', 'cell_type', 'assay', 'disease', 'sex', 'tissue', 'development_stage', 'batch', 'n_genes_by_counts', 'total_counts', 'leiden'
        var: 'ensembl_gene_id-0', 'chromosome_name-0', 'description-0', 'gene_biotype-0', 'n_cells_by_counts', 'mean_counts', 'pct_dropout_by_counts', 'total_counts', 'highly_variable', 'means', 'dispersions', 'dispersions_norm', 'mean', 'std'
        uns: 'annotation_level_1_colors', 'annotation_level_2_colors', 'annotation_level_3_colors', 'assay_colors', 'author_colors', 'hvg', 'leiden', 'leiden_colors', 'neighbors', 'pca', 'stage_colors', 'umap'
        obsm: 'X_pca', 'X_pca_harmony', 'X_umap'
        varm: 'PCs'
        obsp: 'connectivities', 'distances'




```python
adata.shape[0] - adata[adata.obs['stage'].isin([ 'Recurrent', 'Recurrent neo-aPD1']),:].shape[0]
```




    51674




```python
adata.obs['stage'].value_counts(normalize=True).mul(100)
```




    Recurrent             48.725202
    Primary               31.300480
    Metastasis            14.998883
    Recurrent neo-aPD1     3.191648
    Normal                 1.783787
    Name: stage, dtype: float64




```python
df2.head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>donor_id</th>
      <th>stage</th>
      <th>leiden</th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>3</td>
      <td>44.881890</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>2</td>
      <td>17.322835</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>10</td>
      <td>15.748031</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>7</td>
      <td>6.299213</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>4</td>
      <td>5.511811</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>5</td>
      <td>3.937008</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>0</td>
      <td>2.362205</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>6</td>
      <td>2.362205</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>8</td>
      <td>0.787402</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Breast_2</td>
      <td>Metastasis</td>
      <td>1</td>
      <td>0.787402</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Colorectal</td>
      <td>Metastasis</td>
      <td>1</td>
      <td>24.617737</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Colorectal</td>
      <td>Metastasis</td>
      <td>3</td>
      <td>23.241590</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Colorectal</td>
      <td>Metastasis</td>
      <td>2</td>
      <td>21.559633</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Colorectal</td>
      <td>Metastasis</td>
      <td>0</td>
      <td>15.596330</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Colorectal</td>
      <td>Metastasis</td>
      <td>10</td>
      <td>5.504587</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
